import {test, expect, type Page} from '@playwright/test';

async function openNotifications(page: Page, width: number, height: number) {
  await page.setViewportSize({width, height});
  await page.addInitScript(() => {
    localStorage.setItem('hn-wms.s00.language.v1', 'vi');
    localStorage.setItem('hn-wms.s00.theme.v1', 'light');
  });
  await page.goto(`/tests/visual/notification.html?run=semantics-${Date.now()}-${width}`);
  await page.locator('#open-center').click();
  await expect(page.locator('dialog[open]')).toBeVisible();
  await expect(page.locator('#persisted-unread')).toHaveText('2');
  return page.locator('dialog[open]');
}

for (const [width, height] of [[1920, 1080], [800, 1280]]) {
  test(`shared semantics: dialog has a heading without a nested page banner at ${width}`, async ({page}) => {
    const dialog = await openNotifications(page, width, height);
    await expect(dialog).toHaveAccessibleName(/Trung tâm thông báo/);
    await expect(dialog.getByRole('heading', {name: /Trung tâm thông báo/})).toBeVisible();
    await expect(dialog.getByRole('banner')).toHaveCount(0);
    await dialog.getByRole('button', {name: 'Đóng trung tâm thông báo', exact: true}).focus();
    await page.keyboard.press('Escape');
    await expect(dialog).toHaveCount(0);
    await expect(page.locator('#open-center')).toBeFocused();
  });

  test(`shared semantics: named feedback group preserves live status and dismiss at ${width}`, async ({page}) => {
    const dialog = await openNotifications(page, width, height);
    const feedback = page.getByRole('group', {name: 'Thông báo tạm thời', exact: true, includeHidden: true});
    await expect(feedback).toHaveCount(1);
    await dialog.getByRole('button', {name: 'Đánh dấu tất cả đã đọc', exact: true}).click();
    await expect(page.locator('#persisted-unread')).toHaveText('0');
    await page.keyboard.press('Escape');
    await expect(page.locator('dialog[open]')).toHaveCount(0);
    await expect(feedback).toBeVisible();
    const status = feedback.getByRole('status');
    await expect(status).toBeVisible();
    await expect(status).toHaveAttribute('aria-atomic', 'true');
    await expect(status).toContainText('Thao tác thành công');
    await status.getByRole('button', {name: 'Đóng thông báo', exact: true}).click();
    await expect(feedback.getByRole('status')).toHaveCount(0);
    await expect(page.locator('#open-center')).toBeFocused();
  });
}
